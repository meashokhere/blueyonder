package com.blueyonder.domain.controller;

import com.blueyonder.domain.model.Product;
import com.blueyonder.domain.service.BlueyonderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("sortProducts")
public class BlueController {

    @Autowired
    BlueyonderService blueyonderService;

    @PostMapping("sortProducts")
        public ResponseEntity sortProducts(@RequestBody String productList) throws Exception
        {
            blueyonderService.sortedJson(productList);
            return ResponseEntity.status(HttpStatus.OK).body(productList);

        }
    @PostMapping("getProdAvailability")
    public ResponseEntity getProdAvailability(@RequestBody String productList) throws Exception
    {
        blueyonderService.sortedJson(productList);
        return ResponseEntity.status(HttpStatus.OK).body(productList);

    }


}
