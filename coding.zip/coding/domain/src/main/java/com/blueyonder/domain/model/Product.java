package com.blueyonder.domain.model;

import java.util.Date;

public class Product {

    String productId;
    String productName;
    String unitOfMeasure;
    java.util.Date launchDate;

    public void setLaunchDate(java.util.Date launchDate) {
        this.launchDate = launchDate;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }



    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }
}
