package com.blueyonder.domain.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;

import java.util.Comparator;

@Service
public class BlueyonderServiceImpl implements BlueyonderService {

    @Override
    public String sortedJson(String productList) {
        JsonObject  json = new Gson().fromJson(productList,JsonObject.class);
        System.out.println(json);
        JsonArray jsonArray = (JsonArray) json.get("productList");
       // jsonArray.stream().sorted(Comparator.comparing(a -> ((JsonObject) a).get("launchDate")));
        return json.toString();
    }
}
