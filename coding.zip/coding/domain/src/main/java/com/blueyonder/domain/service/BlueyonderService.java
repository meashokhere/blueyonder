package com.blueyonder.domain.service;

public interface BlueyonderService {

    public String sortedJson(String productList);
       
}
