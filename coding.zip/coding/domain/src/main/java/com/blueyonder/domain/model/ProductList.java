package com.blueyonder.domain.model;

import java.util.List;

public class ProductList {
   List<Product> productList;

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
}
